import ListItem from './ListItem';

describe('function',()=>{
  it('update',()=>{
    const todo={id:1,desc:'hello'};
    const LI =new ListItem();
    LI.updateItem(todo);
    expect(LI.state.updateTodo).toEqual(todo);
  })
})