import { addTodo } from './todoAction';
import React from 'react';
const expectedaddTodo ={
  type: "ADD_TODO",
  payload: {id:1,desc:'hello'}
}

describe('actions should create expected object',()=>{
  it('AddToDo function should return same output',()=>{
    expect(addTodo({id:1,desc:'hello'})).toEqual(expectedaddTodo);
  })
})

